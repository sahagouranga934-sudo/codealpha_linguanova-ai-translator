import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import FadingVideo from "./components/FadingVideo";
import BlurText from "./components/BlurText";
import TranslationTool from "./components/TranslationTool";

// Custom SVG Icons
const MicIcon = () => (
  <div className="relative flex items-center justify-center">
    {/* Subtle animated glowing ring behind the mic */}
    <motion.div
      animate={{
        scale: [1, 1.4, 1],
        opacity: [0.3, 0.65, 0.3],
      }}
      transition={{
        duration: 2.2,
        repeat: Infinity,
        ease: "easeInOut",
      }}
      className="absolute w-8 h-8 rounded-full bg-cyan-500/35 blur-md"
    />
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-white relative z-10">
      <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
      <path d="M19 10v1a7 7 0 0 1-14 0v-1" />
      <line x1="12" x2="12" y1="19" y2="22" />
    </svg>
  </div>
);

const BrainIcon = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-white">
    <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M12 5v14" />
    <path d="M12 9h4" />
    <path d="M12 14h-4" />
  </svg>
);

const ArrowUpRightIcon = ({ className = "h-5 w-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="7" y1="17" x2="17" y2="7" />
    <polyline points="7 7 17 7 17 17" />
  </svg>
);

const PlayIcon = ({ className = "h-4 w-4" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <polygon points="6,4 20,12 6,20" />
  </svg>
);

export default function App() {
  const [showTranslator, setShowTranslator] = useState(false);

  return (
    <div className="relative w-full min-h-screen bg-black text-white selection:bg-cyan-500/30 font-body overflow-x-hidden">
      
      <AnimatePresence mode="wait">
        {!showTranslator ? (
          <motion.div
            key="space-voyage"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="w-full flex flex-col"
          >
            {/* Section 1 — Hero */}
            <section
              id="hero"
              className="relative min-h-screen w-full flex flex-col justify-between items-center overflow-hidden bg-black pt-16 pb-8"
            >
              {/* Background video (120% width/height, top-aligned, centered horizontally) */}
              <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
                <FadingVideo
                  src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260418_080021_d598092b-c4c2-4e53-8e46-94cf9064cd50.mp4"
                  className="absolute left-1/2 top-0 -translate-x-1/2 object-cover object-top z-0"
                  style={{ width: "120%", height: "120%" }}
                />
              </div>

              {/* Content layer */}
              <div className="relative z-10 w-full max-w-7xl mx-auto px-4 md:px-8 flex-1 flex flex-col items-center justify-center text-center -mt-4 sm:-mt-8 md:-mt-12">
                
                {/* Badge (delay 0.4s) */}
                <motion.div
                  initial={{ filter: "blur(10px)", opacity: 0, y: 20 }}
                  animate={{ filter: "blur(0px)", opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
                  className="liquid-glass rounded-full text-white/90 p-1 flex items-center justify-center max-w-lg mb-6 leading-none self-center"
                >
                  <span className="bg-white text-black font-semibold text-xs px-3 py-1 rounded-full whitespace-nowrap">
                    🌐 Global Communication Made Simple
                  </span>
                </motion.div>

                {/* Animated word-by-word Blur Headline */}
                <div className="mb-4">
                  <BlurText text="Translate Beyond Boundaries" />
                </div>

                {/* Subheading (delay 0.8s) */}
                <motion.p
                  initial={{ filter: "blur(10px)", opacity: 0, y: 20 }}
                  animate={{ filter: "blur(0px)", opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.8, ease: "easeOut" }}
                  className="mt-4 text-xs sm:text-sm md:text-base text-white/85 max-w-2xl font-body font-light leading-relaxed mb-8 text-center"
                >
                  Experience fast, accurate, and intelligent AI-powered translation that connects people, ideas, and cultures across every language.
                </motion.p>

                {/* CTAs (delay 1.1s) */}
                <motion.div
                  initial={{ filter: "blur(10px)", opacity: 0, y: 20 }}
                  animate={{ filter: "blur(0px)", opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 1.1, ease: "easeOut" }}
                  className="flex flex-wrap items-center justify-center gap-6"
                >
                  <button
                    onClick={() => setShowTranslator(true)}
                    className="cursor-pointer liquid-glass-strong rounded-full px-8 py-3.5 text-base font-semibold text-white flex items-center justify-center gap-2.5 hover:bg-white/15 transition-all outline-none shadow-xl tracking-wider uppercase font-body"
                  >
                    Open Translator
                    <ArrowUpRightIcon className="h-5 w-5" />
                  </button>
                </motion.div>

                {/* Feature cards (delay 1.3s) */}
                <motion.div
                  initial={{ filter: "blur(10px)", opacity: 0, y: 20 }}
                  animate={{ filter: "blur(0px)", opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 1.3, ease: "easeOut" }}
                  className="flex flex-col sm:flex-row items-center justify-center gap-5 mt-10 w-full px-4"
                >
                  {/* Card 1: Voice Translation */}
                  <motion.div
                    whileHover={{ scale: 1.04, y: -2 }}
                    transition={{ type: "spring", stiffness: 400, damping: 15 }}
                    className="liquid-glass rounded-xl p-5 w-full max-w-[270px] sm:w-[270px] flex flex-col items-start text-left h-40 justify-between select-none cursor-default"
                  >
                    <MicIcon />
                    <div>
                      <h4 className="font-heading italic text-2xl md:text-3xl text-white tracking-tight leading-none mb-1.5">
                        Voice Translation
                      </h4>
                      <p className="text-xs text-white/70 font-body font-light leading-snug">
                        Speak naturally and get instant translations.
                      </p>
                    </div>
                  </motion.div>

                  {/* Card 2: AI Context Engine */}
                  <motion.div
                    whileHover={{ scale: 1.04, y: -2 }}
                    transition={{ type: "spring", stiffness: 400, damping: 15 }}
                    className="liquid-glass rounded-xl p-5 w-full max-w-[270px] sm:w-[270px] flex flex-col items-start text-left h-40 justify-between select-none cursor-default"
                  >
                    <BrainIcon />
                    <div>
                      <h4 className="font-heading italic text-2xl md:text-3xl text-white tracking-tight leading-none mb-1.5">
                        AI Context Engine
                      </h4>
                      <p className="text-xs text-white/70 font-body font-light leading-snug">
                        Understands meaning, not just words.
                      </p>
                    </div>
                  </motion.div>
                </motion.div>

              </div>

              {/* Partners (bottom of hero, delay 1.4s) */}
              <motion.div
                initial={{ filter: "blur(10px)", opacity: 0, y: 20 }}
                animate={{ filter: "blur(0px)", opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 1.4, ease: "easeOut" }}
                className="relative z-10 w-full flex flex-col items-center gap-4 pb-4 px-4 mt-8 sm:mt-12"
              >
                <div className="liquid-glass rounded-full px-4 py-1 text-xs text-white/80 font-medium font-body">
                  Supported translating languages
                </div>
                <div className="flex flex-wrap justify-center items-center gap-x-6 gap-y-3 max-w-4xl font-heading italic text-xl md:text-2xl text-white/70 tracking-tight select-none">
                  <span className="hover:text-white transition-colors cursor-default">English</span>
                  <span className="text-white/20 font-body not-italic text-sm">•</span>
                  <span className="hover:text-white transition-colors cursor-default">Spanish</span>
                  <span className="text-white/20 font-body not-italic text-sm">•</span>
                  <span className="hover:text-white transition-colors cursor-default">French</span>
                  <span className="text-white/20 font-body not-italic text-sm">•</span>
                  <span className="hover:text-white transition-colors cursor-default">German</span>
                  <span className="text-white/20 font-body not-italic text-sm">•</span>
                  <span className="hover:text-white transition-colors cursor-default">Japanese</span>
                  <span className="text-white/20 font-body not-italic text-sm">•</span>
                  <span className="hover:text-white transition-colors cursor-default">Chinese</span>
                  <span className="text-white/20 font-body not-italic text-sm">•</span>
                  <span className="hover:text-white transition-colors cursor-default">Hindi</span>
                  <span className="text-white/20 font-body not-italic text-sm">•</span>
                  <span className="hover:text-white transition-colors cursor-default">Bengali</span>
                  <span className="text-white/20 font-body not-italic text-sm">•</span>
                  <span className="hover:text-white transition-colors cursor-default">Arabic</span>
                </div>
              </motion.div>

            </section>


          </motion.div>
        ) : (
          <motion.div
            key="translator-portal"
            initial={{ opacity: 0, scale: 0.95, filter: "blur(10px)" }}
            animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
            exit={{ opacity: 0, scale: 0.95, filter: "blur(10px)" }}
            transition={{ 
              type: "spring", 
              stiffness: 80, 
              damping: 15, 
              mass: 1.1 
            }}
            className="w-full flex-1 min-h-screen flex flex-col justify-center items-center"
          >
            <TranslationTool onBack={() => setShowTranslator(false)} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
