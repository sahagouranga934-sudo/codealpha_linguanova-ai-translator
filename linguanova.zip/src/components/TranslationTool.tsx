import { useState, useEffect, useRef, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import FadingVideo from "./FadingVideo";
import { 
  Languages, 
  Volume2, 
  Mic, 
  MicOff, 
  Copy, 
  Download, 
  Trash2, 
  ArrowLeftRight, 
  Loader2, 
  History, 
  Check, 
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  Settings
} from "lucide-react";

interface TranslationToolProps {
  onBack?: () => void;
}

const LANGUAGES = [
  { name: "English", code: "en", speechCode: "en-US" },
  { name: "Spanish", code: "es", speechCode: "es-ES" },
  { name: "French", code: "fr", speechCode: "fr-FR" },
  { name: "German", code: "de", speechCode: "de-DE" },
  { name: "Japanese", code: "ja", speechCode: "ja-JP" },
  { name: "Chinese", code: "zh-CN", speechCode: "zh-CN" },
  { name: "Hindi", code: "hi", speechCode: "hi-IN" },
  { name: "Bengali", code: "bn", speechCode: "bn-IN" },
  { name: "Arabic", code: "ar", speechCode: "ar-SA" }
];

interface HistoryItem {
  id: string;
  originalText: string;
  translatedText: string;
  sourceLang: string;
  targetLang: string;
  timestamp: string;
  pronunciationGuide?: string;
}

const SUGGESTED_STATEMENTS = [
  { text: "Hello, we come in peace to explore your beautiful galaxy.", icon: "🌌" },
  { text: "What are the coordinates for the nearest fueling station on Mars?", icon: "🚀" },
  { text: "Initiating deep space hyperdrive warp sequence.", icon: "⚡" },
  { text: "Please warn the crew that solar radiation is elevated today.", icon: "☀️" },
  { text: "Are there any indicators of habitable atmospheres on this planet?", icon: "🪐" }
];

const historyContainerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
    },
  },
};

const historyCardVariants = {
  hidden: { opacity: 0, y: 24, scale: 0.97 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 15,
    },
  },
  exit: {
    opacity: 0,
    scale: 0.95,
    transition: { duration: 0.18 },
  },
};

export default function TranslationTool({ onBack }: TranslationToolProps) {
  const [inputText, setInputText] = useState("");
  const [translatedText, setTranslatedText] = useState("");
  const [displayedText, setDisplayedText] = useState("");
  const [pronunciationGuide, setPronunciationGuide] = useState("");
  const [isDecrypting, setIsDecrypting] = useState(false);
  const [sourceLang, setSourceLang] = useState("auto");
  const [targetLang, setTargetLang] = useState("es");
  
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [isCopiedOriginal, setIsCopiedOriginal] = useState(false);
  const [isCopiedTranslated, setIsCopiedTranslated] = useState(false);
  const isLightMode = false;
  const [particleDensity, setParticleDensity] = useState(25);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [detectedLangCode, setDetectedLangCode] = useState<string | null>(null);
  const [detectedLangName, setDetectedLangName] = useState<string | null>(null);
  const [isLocalFallbackActive, setIsLocalFallbackActive] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [swapRotation, setSwapRotation] = useState(0);

  const recognitionRef = useRef<any>(null);
  const suggestionsRef = useRef<HTMLDivElement>(null);

  const scrollSuggestions = (direction: "left" | "right") => {
    if (suggestionsRef.current) {
      const scrollAmount = direction === "left" ? -240 : 240;
      suggestionsRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" });
    }
  };

  // Snappy Quantum Typewriter Decryption algorithm
  useEffect(() => {
    if (!translatedText) {
      setDisplayedText("");
      setIsDecrypting(false);
      return;
    }

    setIsDecrypting(true);
    let currentStep = 0;
    const targetText = translatedText;
    const targetLength = targetText.length;
    
    // Snappier speed for long documents, aesthetic typing for short messages
    const intervalMs = targetLength > 150 ? 5 : 12;
    const charsPerStep = targetLength > 250 ? 4 : (targetLength > 100 ? 2 : 1);

    const decryptPool = "0101XØΔΨΩΦΞΛΓΣΠ▲▼◆◇●○01Ø╳☄✦✧⌬⚿";

    const interval = setInterval(() => {
      currentStep += charsPerStep;
      if (currentStep >= targetLength) {
        setDisplayedText(targetText);
        setIsDecrypting(false);
        clearInterval(interval);
      } else {
        const decryptedPart = targetText.slice(0, currentStep);
        const noiseLength = Math.min(4, targetLength - currentStep);
        let noisePart = "";
        for (let i = 0; i < noiseLength; i++) {
          noisePart += decryptPool[Math.floor(Math.random() * decryptPool.length)];
        }
        setDisplayedText(decryptedPart + noisePart);
      }
    }, intervalMs);

    return () => {
      clearInterval(interval);
    };
  }, [translatedText]);

  // Load history and pre-trigger browser voice synthesis engines on mount
  useEffect(() => {
    fetchHistory();
    if (typeof window !== "undefined" && window.speechSynthesis) {
      const loadVoicesOnMount = () => {
        const list = window.speechSynthesis.getVoices();
        setVoices(list);
      };
      
      loadVoicesOnMount();
      
      if (window.speechSynthesis.onvoiceschanged !== undefined) {
        window.speechSynthesis.onvoiceschanged = loadVoicesOnMount;
      }
    }
  }, []);

  // Global Keyboard Shortcuts (Ctrl+Enter to translate, Ctrl+Shift+S to swap languages)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+Enter or Cmd+Enter to Translate
      if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
        if (inputText.trim() && !isLoading) {
          e.preventDefault();
          handleTranslate();
        }
      }
      // Ctrl+Shift+S or Cmd+Shift+S to Swap languages
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === "s") {
        e.preventDefault();
        handleSwap();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [inputText, sourceLang, targetLang, translatedText, isLoading]);

  const fetchHistory = async () => {
    try {
      const response = await fetch("/api/history");
      if (response.ok) {
        const data = await response.json();
        setHistory(data);
      }
    } catch (err) {
      console.error("Failed to load translation history:", err);
    }
  };

  const clearHistory = async () => {
    try {
      const response = await fetch("/api/history/clear", { method: "POST" });
      if (response.ok) {
        setHistory([]);
      }
    } catch (err) {
      console.error("Failed to clear history:", err);
    }
  };

  const handleTranslate = async () => {
    if (!inputText.trim()) return;
    setIsLoading(true);
    setError(null);
    setIsLocalFallbackActive(false);
    try {
      const response = await fetch("/api/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: inputText,
          sourceLang,
          targetLang
        })
      });

      if (!response.ok) {
        let errMsg = "Translation failed. Please check your network and API credentials.";
        try {
          const errData = await response.json();
          if (errData && errData.error) {
            errMsg = errData.error;
          }
        } catch {
          // ignore parsing error
        }
        throw new Error(errMsg);
      }

      const data = await response.json();
      setTranslatedText(data.translatedText);
      setPronunciationGuide(data.pronunciationGuide || "");
      setIsLocalFallbackActive(!!data.isFallbackLocal);
      
      if (sourceLang === "auto" && data.detectedLanguage) {
        setDetectedLangName(data.detectedLanguage);
        setDetectedLangCode(data.detectedLanguageCode);
      } else {
        setDetectedLangName(null);
        setDetectedLangCode(null);
      }
      
      // refresh history
      fetchHistory();
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred during translation.");
    } finally {
      setIsLoading(false);
    }
  };

  // Swap Languages
  const handleSwap = () => {
    setSwapRotation(prev => prev + 180);
    if (sourceLang === "auto") {
      // Cannot fully swap auto, switch auto to previous target or default
      setSourceLang(targetLang);
      setTargetLang("en");
    } else {
      const temp = sourceLang;
      setSourceLang(targetLang);
      setTargetLang(temp);
    }
    // Also swap contents to be helpful
    if (translatedText) {
      setInputText(translatedText);
      setTranslatedText(inputText);
      setPronunciationGuide("");
    }
  };

  // Text to Speech with robust localized voice matching, optimized for all supported languages (like French, German, Bengali)
  const handleSpeak = (text: string, langCode: string) => {
    if (!text) return;
    try {
      window.speechSynthesis.cancel();
      // Match correct speech code or fallback
      const match = LANGUAGES.find(l => l.code === langCode);
      const speechCode = match ? match.speechCode : "en-US";
      const langName = match ? match.name : "";
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = speechCode;
      
      // Fallback to direct fetch if the voices array state is somehow empty
      const currentVoices = voices.length > 0 ? voices : window.speechSynthesis.getVoices();
      
      let targetVoice: SpeechSynthesisVoice | undefined;

      if (currentVoices && currentVoices.length > 0) {
        const cleanLangCode = langCode.toLowerCase();
        const cleanSpeechCode = speechCode.toLowerCase().replace('_', '-');

        // Scored matching: we evaluate and find the best match with the highest compatibility score
        const scoredVoices = currentVoices.map(voice => {
          const vLang = voice.lang.toLowerCase().replace('_', '-');
          const vName = voice.name.toLowerCase();
          let score = 0;

          // Tier 1: Exact locale code match (e.g., 'fr-fr' vs 'fr-fr')
          if (vLang === cleanSpeechCode || vLang.replace('-', '_') === cleanSpeechCode.replace('-', '_')) {
            score += 100;
          }
          // Tier 2: Sub-locale match (e.g., 'fr-ca' vs 'fr' language code)
          else if (vLang === cleanLangCode || vLang.startsWith(cleanLangCode + "-") || vLang.startsWith(cleanLangCode + "_")) {
            score += 50;
            // Native dialect quality tuning for primary languages (German, French, Spanish, English)
            if (cleanLangCode === "fr" && vLang.includes("fr-fr")) score += 20;
            if (cleanLangCode === "de" && vLang.includes("de-de")) score += 20;
            if (cleanLangCode === "es" && vLang.includes("es-es")) score += 20;
            if (cleanLangCode === "en" && (vLang.includes("en-us") || vLang.includes("en-gb"))) score += 20;
          }

          // Tier 3: Substring linguistic name matching (e.g. voice is named "french", "deutsch" or "bengali")
          if (langName) {
            const cleanLangName = langName.toLowerCase();
            if (vName.includes(cleanLangName)) {
              score += 30;
            }
            if (cleanLangName === "german" && vName.includes("deutsch")) {
              score += 30;
            }
            if (cleanLangName === "spanish" && (vName.includes("español") || vName.includes("espanol"))) {
              score += 30;
            }
            if (cleanLangName === "bengali" && vName.includes("bangla")) {
              score += 30;
            }
          }

          // Tier 4: Preference boost for high-fidelity natural TTS synthesizers
          if (vName.includes("natural") || vName.includes("neural") || vName.includes("premium") || vName.includes("google")) {
            score += 15;
          }

          return { voice, score };
        });

        const sorted = scoredVoices.filter(item => item.score > 0).sort((a, b) => b.score - a.score);
        if (sorted.length > 0) {
          targetVoice = sorted[0].voice;
        }
      }

      // Tier 5: Direct substring prefix fallback
      if (!targetVoice && currentVoices && currentVoices.length > 0) {
        targetVoice = currentVoices.find(v => v.lang.toLowerCase().startsWith(langCode.toLowerCase()));
      }

      if (targetVoice) {
        utterance.voice = targetVoice;
        console.log("Selected TTS Voice via Enhanced Scoring System:", targetVoice.name, targetVoice.lang);
      } else {
        console.warn("No specific localized voice found for code:", langCode);
      }

      // Standardize speed for optimal clarity
      if (langCode === "bn" || speechCode.startsWith("bn")) {
        // Bengali sounds more natural and understandable in synth engines at a slightly measured rate
        utterance.rate = 0.85;
      } else if (langCode === "de" || speechCode.startsWith("de")) {
        // German voice benefits from a slightly measured pace to assist space-telemetry aesthetics
        utterance.rate = 0.95;
      } else if (langCode === "fr" || speechCode.startsWith("fr")) {
        // French standard pacing
        utterance.rate = 0.98;
      } else {
        utterance.rate = 1.0;
      }
      utterance.pitch = 1.0;

      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.error("Text-to-speech error:", err);
    }
  };

  // Voice Input (Speech Recognition)
  const toggleListening = () => {
    setError(null); // Clear previous errors
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setError("Speech recognition is not supported in this browser. Please try using Google Chrome, Safari, or Microsoft Edge.");
      return;
    }

    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
    } else {
      const recognition = new SpeechRecognition();
      recognitionRef.current = recognition;
      recognition.continuous = true;
      recognition.interimResults = true;

      const currentSource = sourceLang === "auto" ? "en" : sourceLang;
      const match = LANGUAGES.find(l => l.code === currentSource);
      recognition.lang = match ? match.speechCode : "en-US";

      let finalTranscript = "";

      recognition.onstart = () => {
        setIsListening(true);
        setError(null);
      };

      recognition.onresult = (event: any) => {
        let interimTranscript = "";
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript + " ";
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
        const currentText = finalTranscript + interimTranscript;
        if (currentText.trim()) {
          setInputText(currentText.trim());
        }
      };

      recognition.onerror = (e: any) => {
        console.error("Speech Recognition Engine Error:", e);
        setIsListening(false);
        if (e.error === "not-allowed") {
          setError("Microphone access is denied. Please enable microphone permissions in your browser's site settings.");
        } else if (e.error === "no-speech") {
          setError("No speech was detected. Please make sure your mic is unmuted and try speaking again.");
        } else if (e.error === "network") {
          setError("Chrome's cloud Web Speech service is restricted inside sandboxed design previews. Open this application in a standalone tab to translate your voice instantly!");
        } else if (e.error === "aborted") {
          // Normal stop pattern, no error display needed
        } else {
          setError(`Speech input issue: ${e.error || "unknown failure"}. Please try again.`);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      try {
        recognition.start();
      } catch (err) {
        console.error("Failed to start speech recognition:", err);
        setError("Unable to initialize microphone stream. Please check your audio inputs.");
        setIsListening(false);
      }
    }
  };

  const copyToClipboard = async (text: string, isOriginal: boolean) => {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      if (isOriginal) {
        setIsCopiedOriginal(true);
        setTimeout(() => setIsCopiedOriginal(false), 2000);
      } else {
        setIsCopiedTranslated(true);
        setTimeout(() => setIsCopiedTranslated(false), 2000);
      }
    } catch (err) {
      console.error("Clipboard copy failed:", err);
    }
  };

  const downloadText = (text: string, filename: string) => {
    if (!text) return;
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const selectHistoryItem = (item: HistoryItem) => {
    setInputText(item.originalText);
    setTranslatedText(item.translatedText);
    setPronunciationGuide(item.pronunciationGuide || "");
    setSourceLang(item.sourceLang);
    setTargetLang(item.targetLang);
    setDetectedLangCode(null);
    setDetectedLangName(null);
  };

  // Memoized particles generator for floating ambient bg to prevent chaotic flickering on other states
  const particles = useMemo(() => {
    return Array.from({ length: particleDensity }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 3 + 1,
      delay: Math.random() * 5,
      duration: Math.random() * 10 + 15
    }));
  }, [particleDensity]);

  return (
    <div className={`relative min-h-screen py-24 px-4 w-full flex flex-col items-center justify-start overflow-hidden transition-colors duration-500 ${isLightMode ? "bg-slate-50 text-slate-800" : "bg-black text-slate-100"}`}>
      
      {/* Foggy Space Voyage Landscape (Frosted glass backdrop) */}
      <div className={`absolute inset-0 z-0 pointer-events-none overflow-hidden transition-opacity duration-500 ${isLightMode ? "opacity-30" : "opacity-75"}`}>
        <FadingVideo
          src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260418_080021_d598092b-c4c2-4e53-8e46-94cf9064cd50.mp4"
          className="absolute left-1/2 top-0 -translate-x-1/2 object-cover object-top z-0"
          style={{ width: "120%", height: "120%", filter: "blur(12px) brightness(0.55)" }}
        />
        {/* Soft atmospheric gradients for depth and premium feel */}
        <div className={`absolute inset-0 transition-colors duration-500 ${isLightMode ? "bg-white/40" : "bg-gradient-to-b from-black/25 via-black/40 to-black/65"}`} />
      </div>

      {/* Animated Glowing Ambient Background */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <div className={`absolute -top-[20%] -left-[10%] w-[50%] h-[50%] rounded-full blur-[140px] opacity-40 transition-colors duration-500 ${isLightMode ? "bg-cyan-200" : "bg-cyan-950"}`} />
        <div className={`absolute -bottom-[20%] -right-[10%] w-[50%] h-[50%] rounded-full blur-[140px] opacity-30 transition-colors duration-500 ${isLightMode ? "bg-cyan-100" : "bg-cyan-900"}`} />
        
        {/* Floating space dust/particles */}
        {particles.map((p) => (
          <motion.div
            key={p.id}
            initial={{ y: "110%", x: `${p.x}%`, opacity: 0 }}
            animate={{ 
              y: ["110%", "-10%"],
              opacity: [0, 0.6, 0.6, 0],
              x: [`${p.x}%`, `${p.x + (Math.random() * 10 - 5)}%`]
            }}
            transition={{
              duration: p.duration,
              delay: p.delay,
              repeat: Infinity,
              ease: "linear"
            }}
            className={`absolute rounded-full pointer-events-none ${isLightMode ? "bg-cyan-300/40" : "bg-cyan-400/40"}`}
            style={{
              width: p.size,
              height: p.size,
              top: 0
            }}
          />
        ))}
      </div>

      <div className="relative z-10 w-full max-w-5xl flex flex-col items-center">
        
        {/* Floating Utilities Bar */}
        <div className="w-full flex items-center justify-between mb-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-3"
          >
            <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-500">
              <Languages className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-xl font-heading font-semibold tracking-wide italic leading-none text-cyan-400" id="translator-app-title">
                LinguaNova
              </h1>
              <span className={`text-[11px] font-mono tracking-wider ${isLightMode ? "text-slate-400" : "text-slate-500"}`} id="translator-app-tagline">
                Translate Beyond Boundaries
              </span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2"
          >
            {/* Atmosphere settings slider toggle */}
            <button
              onClick={() => setIsSettingsOpen(!isSettingsOpen)}
              className={`liquid-glass p-2 px-3 rounded-xl transition-all duration-300 flex items-center justify-center gap-1.5 ${
                isSettingsOpen 
                ? (isLightMode ? "bg-slate-200 text-cyan-600 font-semibold" : "bg-white/10 text-cyan-400 font-semibold") 
                  : (isLightMode ? "text-slate-700 hover:bg-white/20" : "text-slate-300 hover:bg-white/[0.04]")
              }`}
              title="Atmosphere Settings"
              id="atmosphere-settings-btn"
            >
              <Settings className={`h-4 w-4 ${isSettingsOpen ? 'animate-spin' : ''}`} style={{ animationDuration: '6s' }} />
              <span className="text-xs font-mono tracking-wide">Atmosphere</span>
            </button>

            {onBack && (
              <button
                onClick={onBack}
                className={`liquid-glass px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${isLightMode ? "text-slate-700 hover:bg-white/20" : "text-slate-300 hover:bg-white/[0.04]"}`}
                id="exit-portal-btn"
              >
                Exit Portal
              </button>
            )}
          </motion.div>
        </div>

        {/* Atmosphere Space settings panel */}
        <AnimatePresence>
          {isSettingsOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0, y: -12 }}
              animate={{ opacity: 1, height: "auto", y: 0 }}
              exit={{ opacity: 0, height: 0, y: -12 }}
              transition={{ type: "spring", stiffness: 150, damping: 17 }}
              className={`w-full overflow-hidden mb-6 rounded-2xl border transition-colors duration-500 shadow-xl backdrop-blur-md ${
                isLightMode 
                  ? "bg-white/80 border-slate-200 text-slate-800 shadow-slate-200/40" 
                  : "bg-slate-950/80 border-white/10 text-slate-100 shadow-black/60"
              }`}
              id="atmosphere-control-panel"
            >
              <div className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex-1">
                  <h3 className="font-heading font-semibold tracking-wide text-xs sm:text-sm flex items-center gap-2 text-cyan-400">
                    <Settings className="h-4 w-4 animate-pulse text-cyan-500" />
                    SPACE DEBRIS CONFIGURATION
                  </h3>
                  <p className={`text-xs mt-1 leading-relaxed ${isLightMode ? "text-slate-500" : "text-slate-400"}`}>
                    Calibrate the visual gravity. Scale particle count higher for dense cosmic trails, or turn it down to zero for completely sterile viewport dynamics.
                  </p>
                </div>

                <div className={`p-4 rounded-xl border flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full md:w-auto min-w-[280px] sm:min-w-[380px] ${
                  isLightMode ? "bg-slate-50/60 border-slate-200/80" : "bg-black/40 border-white/5"
                }`}>
                  <div className="flex-1">
                    <div className="flex justify-between items-center mb-1.5">
                      <label htmlFor="particle-density-slider" className="text-[10px] font-mono font-semibold tracking-wider text-slate-400 uppercase">
                        ✨ Dust Density Gauge
                      </label>
                      <span className="text-[10px] sm:text-xs font-mono font-bold bg-cyan-500/10 px-2.5 py-0.5 rounded-full text-cyan-400 border border-cyan-500/15">
                        {particleDensity} particles
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-[10px] font-mono text-slate-500">Stasis</span>
                      <input
                        id="particle-density-slider"
                        type="range"
                        min="0"
                        max="100"
                        step="1"
                        value={particleDensity}
                        onChange={(e) => setParticleDensity(Number(e.target.value))}
                        className="flex-1 h-1.5 rounded-full appearance-none cursor-pointer bg-slate-300 dark:bg-slate-800 accent-cyan-500 focus:outline-none"
                        style={{
                          background: `linear-gradient(to right, #06b6d4 0%, #06b6d4 ${particleDensity}%, ${isLightMode ? '#cbd5e1' : '#334155'} ${particleDensity}%, ${isLightMode ? '#cbd5e1' : '#334155'} 100%)`
                        }}
                      />
                      <span className="text-[10px] font-mono text-slate-500">Nebula</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>



        {/* Translator Main Grid Card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className={`w-full rounded-3xl p-6 md:p-8 liquid-glass-strong transition-all duration-500 shadow-[0_30px_70px_rgba(0,0,0,0.6)] ${isLightMode ? "bg-white/10 shadow-slate-200/25" : "bg-black/15 shadow-black/85"}`}
        >
          {/* Form Header Action Block */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-6 border-b border-dashed border-slate-200/10">
            {/* Lang dropdown 1 */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className={`text-xs font-mono tracking-wider uppercase ${isLightMode ? "text-slate-400" : "text-slate-500"}`}>FROM:</span>
              <select
                value={sourceLang}
                onChange={(e) => {
                  setSourceLang(e.target.value);
                  setDetectedLangCode(null);
                  setDetectedLangName(null);
                }}
                className={`liquid-glass flex-1 sm:flex-none py-2 px-4 rounded-xl text-sm font-medium outline-none cursor-pointer transition-all ${isLightMode ? "text-slate-800 hover:bg-white/20" : "text-slate-200 hover:bg-white/[0.04]"}`}
              >
                <option value="auto" className={isLightMode ? "bg-white text-slate-800" : "bg-slate-950 text-slate-100"}>Auto-Detect Language</option>
                {LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code} className={isLightMode ? "bg-white text-slate-800" : "bg-slate-950 text-slate-100"}>{l.name}</option>
                ))}
              </select>
            </div>

            {/* Swap Button */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleSwap}
              className={`liquid-glass p-2.5 rounded-xl transition-all duration-300 ${isLightMode ? "text-slate-600 hover:bg-white/20" : "text-slate-300 hover:bg-white/[0.04]"}`}
              title="Swap Languages (Ctrl+Shift+S)"
            >
              <motion.div
                animate={{ rotate: swapRotation }}
                transition={{ type: "spring", stiffness: 200, damping: 15 }}
                className="flex items-center justify-center"
              >
                <ArrowLeftRight className="h-4 w-4" />
              </motion.div>
            </motion.button>

            {/* Lang dropdown 2 */}
            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <span className={`text-xs font-mono tracking-wider uppercase ${isLightMode ? "text-slate-400" : "text-slate-500"}`}>TO:</span>
              <select
                value={targetLang}
                onChange={(e) => setTargetLang(e.target.value)}
                className={`liquid-glass py-2 px-4 rounded-xl text-sm font-medium outline-none cursor-pointer transition-all ${isLightMode ? "text-slate-800 hover:bg-white/20" : "text-slate-200 hover:bg-white/[0.04]"}`}
              >
                {LANGUAGES.filter(v => v.code !== "auto").map((l) => (
                  <option key={l.code} value={l.code} className={isLightMode ? "bg-white text-slate-800" : "bg-slate-950 text-slate-100"}>{l.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Core Text Areas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
            
            {/* Input Card Container */}
            <div className="flex flex-col">
              <div className="relative">
                <textarea
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value.slice(0, 5000))}
                  placeholder="Type or paste text, or use voice input to translate..."
                  className={`liquid-glass w-full h-64 p-5 rounded-2xl text-base outline-none resize-none transition-all ${isLightMode ? "text-slate-800 focus:bg-white/10" : "text-slate-100 focus:bg-white/[0.04]"}`}
                />
                
                {/* Overlay status block indicating active recording state */}
                <AnimatePresence>
                  {isListening && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9, y: -5 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9, y: -5 }}
                      className="absolute top-4 right-4 flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-red-500/10 border border-red-500/20 text-red-500 text-xs font-mono font-medium shadow-md backdrop-blur-xs z-25"
                    >
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                      </span>
                      <span>Listening...</span>
                    </motion.div>
                  )}
                </AnimatePresence>
                
                {/* Micro Input actions (Voice + TTS + Media scanning) */}
                <div className="absolute bottom-3 left-3 flex items-center gap-2 z-20">
                  <button
                    onClick={toggleListening}
                    type="button"
                    className={`p-2.5 rounded-xl transition-all duration-300 backdrop-blur-md flex items-center justify-center relative ${
                      isListening 
                        ? "bg-red-500 text-white shadow-lg shadow-red-500/40 border border-red-400" 
                        : (isLightMode 
                          ? "bg-white/60 hover:bg-white/95 border border-slate-200/50 text-slate-600 hover:text-cyan-600 shadow-sm" 
                          : "bg-slate-900/60 hover:bg-slate-900/95 border border-white/5 text-slate-300 hover:text-cyan-400 shadow-sm")
                    }`}
                    title={isListening ? "Listening... click to stop" : "Voice Input"}
                    id="microphone-transcribe-button"
                  >
                    {isListening ? (
                      <>
                        <motion.span
                          animate={{ scale: [1, 1.4, 1], opacity: [0.35, 0, 0.35] }}
                          transition={{ repeat: Infinity, duration: 1.5 }}
                          className="absolute inset-0 bg-red-500 rounded-xl"
                        />
                        <MicOff className="h-4 w-4 relative z-10 animate-pulse text-white" />
                      </>
                    ) : (
                      <Mic className="h-4 w-4" />
                    )}
                  </button>

                  <button
                    onClick={() => handleSpeak(inputText, sourceLang === "auto" ? (detectedLangCode || "en") : sourceLang)}
                    disabled={!inputText.trim()}
                    className={`p-2 rounded-lg transition-colors backdrop-blur-md ${inputText.trim() ? (isLightMode ? "bg-white/60 hover:bg-white/80 border border-slate-200/50 text-slate-600 shadow-sm" : "bg-slate-900/50 hover:bg-slate-900/70 border border-white/5 text-slate-300 shadow-sm") : "opacity-40 cursor-not-allowed"}`}
                    title="Speak Original Text"
                  >
                    <Volume2 className="h-4 w-4" />
                  </button>
                </div>

                {/* Character Counter */}
                <div className="absolute bottom-3 right-3 text-xs font-mono text-slate-500">
                  {inputText.length} / 5000
                </div>
              </div>

              {/* Suggested transmissions */}
              <div className="mt-4 max-w-full">
                <div className="flex items-center justify-between mb-2.5">
                  <span className={`text-[11px] font-mono tracking-wider uppercase font-semibold ${isLightMode ? "text-slate-500" : "text-slate-400"}`}>
                    🌌 Suggested Transmissions
                  </span>
                  {/* Scrolling Direction Buttons */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => scrollSuggestions("left")}
                      className={`p-1.5 rounded-lg transition-all duration-200 border flex items-center justify-center hover:scale-105 active:scale-95 ${
                        isLightMode 
                          ? "bg-white hover:bg-slate-100 border-slate-200 text-slate-600 shadow-sm" 
                          : "bg-slate-900/60 hover:bg-slate-900/95 border-white/10 text-slate-300 shadow-md shadow-black/40"
                      }`}
                      title="Scroll Left"
                    >
                      <ChevronLeft className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => scrollSuggestions("right")}
                      className={`p-1.5 rounded-lg transition-all duration-200 border flex items-center justify-center hover:scale-105 active:scale-95 ${
                        isLightMode 
                          ? "bg-white hover:bg-slate-100 border-slate-200 text-slate-600 shadow-sm" 
                          : "bg-slate-900/60 hover:bg-slate-900/95 border-white/10 text-slate-300 shadow-md shadow-black/40"
                      }`}
                      title="Scroll Right"
                    >
                      <ChevronRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
                <div 
                  ref={suggestionsRef}
                  className="flex flex-row flex-nowrap overflow-x-auto gap-2 pb-3.5 scroll-smooth max-w-full whitespace-nowrap"
                >
                  {SUGGESTED_STATEMENTS.map((item, i) => (
                    <button
                      key={i}
                      onClick={() => {
                        setInputText(item.text);
                        setTranslatedText("");
                        setPronunciationGuide("");
                      }}
                      className={`liquid-glass text-xs px-4 py-2.5 rounded-full transition-all duration-300 flex items-center gap-2 hover:-translate-y-0.5 outline-none shrink-0 cursor-pointer ${isLightMode ? "text-slate-700 hover:text-slate-900" : "text-slate-300 hover:text-white"}`}
                    >
                      <span className="shrink-0">{item.icon}</span>
                      <span className="max-w-[300px] sm:max-w-[400px] truncate whitespace-nowrap">{item.text}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Utility Clear Indicator */}
              {inputText && (
                <button
                  onClick={() => { setInputText(""); setTranslatedText(""); setPronunciationGuide(""); }}
                  className="self-end mt-2 text-xs font-mono text-rose-500 hover:underline flex items-center gap-1"
                >
                  <Trash2 className="h-3 w-3" /> Clear Active Log
                </button>
              )}
            </div>

            {/* Output Card Container */}
            <div className="flex flex-col">
              <div className="relative">
                <div
                  className={`liquid-glass w-full h-64 p-5 rounded-2xl text-base overflow-y-auto block whitespace-pre-wrap transition-all relative ${isLightMode ? "text-slate-800" : "text-slate-100"}`}
                >
                  {isLoading ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/5 hover:bg-slate-950/10">
                      <Loader2 className="h-8 w-8 text-cyan-500 animate-spin mb-2" />
                      <span className="text-xs font-mono tracking-widest text-cyan-400">DECRYPTING QUANTUM DATA...</span>
                    </div>
                  ) : translatedText ? (
                    <div className="relative">
                      {isDecrypting ? (
                        <motion.span
                          animate={{
                            textShadow: isLightMode
                              ? [
                                  "0 0 4px rgba(6,182,212,0.05)",
                                  "0 0 8px rgba(6,182,212,0.12)",
                                  "0 0 4px rgba(6,182,212,0.05)"
                                ]
                              : [
                                  "0 0 8px rgba(255,255,255,0.15)",
                                  "0 0 14px rgba(255,255,255,0.35)",
                                  "0 0 8px rgba(255,255,255,0.15)"
                                ]
                          }}
                          transition={{
                            duration: 0.8,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                          className={isLightMode ? "text-slate-800" : "text-white"}
                        >
                          {displayedText}
                        </motion.span>
                      ) : (
                        <span className={isLightMode ? "text-slate-800" : "text-white"}>{displayedText}</span>
                      )}
                      {isDecrypting && (
                        <motion.span
                          animate={{
                            opacity: [1, 0.3, 1]
                          }}
                          transition={{
                            duration: 0.8,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                          className={`inline-block w-2 h-4.5 ml-1.5 align-middle select-none ${isLightMode ? "bg-slate-800" : "bg-white"}`}
                        >
                          █
                        </motion.span>
                      )}
                      {!isDecrypting && pronunciationGuide && (
                        <div id="pronunciation-guide-container" className={`mt-4 pt-3 border-t ${isLightMode ? "border-slate-200/50" : "border-white/[0.06]"} text-xs sm:text-sm`}>
                          <p className={`font-mono font-bold uppercase tracking-wider mb-2 text-[10px] sm:text-xs ${isLightMode ? "text-cyan-600" : "text-cyan-400"}`}>
                            Pronunciation Guide:
                          </p>
                          <p className={`italic leading-relaxed ${isLightMode ? "text-slate-600" : "text-slate-300"}`}>
                            {pronunciationGuide}
                          </p>
                        </div>
                      )}
                    </div>
                  ) : (
                    <span className="text-slate-500 italic">Translated text will appear here...</span>
                  )}
                </div>

                {/* Micro Output actions */}
                {translatedText && !isLoading && (
                  <div className="absolute bottom-3 left-3 flex items-center gap-1.5">
                    <button
                      onClick={() => handleSpeak(translatedText, targetLang)}
                      className={`p-2 rounded-lg transition-colors backdrop-blur-md ${isLightMode ? "bg-white/60 hover:bg-white/80 border border-slate-200/50 text-slate-600 shadow-sm" : "bg-slate-900/50 hover:bg-slate-900/70 border border-white/5 text-slate-300 shadow-sm"}`}
                      title="Speak Translation"
                    >
                      <Volume2 className="h-4 w-4" />
                    </button>

                    <button
                      onClick={() => copyToClipboard(translatedText, false)}
                      className={`p-2 rounded-lg transition-colors backdrop-blur-md ${isLightMode ? "bg-white/60 hover:bg-white/80 border border-slate-200/50 text-slate-600 shadow-sm" : "bg-slate-900/50 hover:bg-slate-900/70 border border-white/5 text-slate-300 shadow-sm"}`}
                      title="Copy Target Translation"
                    >
                      {isCopiedTranslated ? <Check className="h-4 w-4 text-emerald-500" /> : <Copy className="h-4 w-4" />}
                    </button>

                    <button
                      onClick={() => downloadText(translatedText, `translated-${targetLang}.txt`)}
                      className={`p-2 rounded-lg transition-colors backdrop-blur-md ${isLightMode ? "bg-white/60 hover:bg-white/80 border border-slate-200/50 text-slate-600 shadow-sm" : "bg-slate-900/50 hover:bg-slate-900/70 border border-white/5 text-slate-300 shadow-sm"}`}
                      title="Download Translation as TXT"
                    >
                      <Download className="h-4 w-4" />
                    </button>
                  </div>
                )}

                {/* Auto Detection indicator */}
                <AnimatePresence>
                  {detectedLangName && (
                    <motion.div
                      initial={{ opacity: 0, y: 8, filter: "blur(4px)" }}
                      animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                      exit={{ opacity: 0, y: 8, filter: "blur(4px)" }}
                      transition={{ duration: 0.4, ease: "easeOut" }}
                      className="absolute bottom-3 right-3 text-xs font-mono px-2.5 py-1.5 rounded-md bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shadow-lg flex items-center gap-1.5 backdrop-blur-xs select-none"
                    >
                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                      Detected: {detectedLangName} ({detectedLangCode})
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

          </div>

          {/* Translation Prompt Errors */}
          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-4 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
              >
                <div className="flex items-center gap-2.5">
                  <AlertCircle className="h-4 w-4 shrink-0 text-rose-500" />
                  <span>{error}</span>
                </div>
                {(error.includes("sandboxed") || error.includes("restricted")) && (
                  <a
                    href={window.location.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="shrink-0 text-xs px-3.5 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-600 transition-colors text-white font-semibold font-mono tracking-wider text-center"
                  >
                    Open in New Tab
                  </a>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Call to action translate button wrapper */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mt-8 pt-6 border-t border-dashed border-slate-200/10">
            <div className={`text-[11px] font-mono tracking-wider flex flex-wrap items-center gap-3.5 select-none ${isLightMode ? "text-slate-400" : "text-slate-500"}`}>
              <div className="flex items-center gap-1.5">
                <kbd className={`px-1.5 py-0.5 rounded border text-[10px] shadow-sm font-semibold font-mono ${isLightMode ? "bg-white border-slate-200 text-slate-500" : "bg-slate-900 border-slate-800 text-slate-400"}`}>Ctrl</kbd>
                <span>+</span>
                <kbd className={`px-1.5 py-0.5 rounded border text-[10px] shadow-sm font-semibold font-mono ${isLightMode ? "bg-white border-slate-200 text-slate-500" : "bg-slate-900 border-slate-800 text-slate-400"}`}>Enter</kbd>
                <span className="ml-1 text-[10px] uppercase">Translate</span>
              </div>
              <span className="opacity-40">•</span>
              <div className="flex items-center gap-1.5">
                <kbd className={`px-1.5 py-0.5 rounded border text-[10px] shadow-sm font-semibold font-mono ${isLightMode ? "bg-white border-slate-200 text-slate-500" : "bg-slate-900 border-slate-800 text-slate-400"}`}>Ctrl</kbd>
                <span>+</span>
                <kbd className={`px-1.5 py-0.5 rounded border text-[10px] shadow-sm font-semibold font-mono ${isLightMode ? "bg-white border-slate-200 text-slate-500" : "bg-slate-900 border-slate-800 text-slate-400"}`}>Shift</kbd>
                <span>+</span>
                <kbd className={`px-1.5 py-0.5 rounded border text-[10px] shadow-sm font-semibold font-mono ${isLightMode ? "bg-white border-slate-200 text-slate-500" : "bg-slate-900 border-slate-800 text-slate-400"}`}>S</kbd>
                <span className="ml-1 text-[10px] uppercase">Swap</span>
              </div>
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              disabled={isLoading || !inputText.trim()}
              onClick={handleTranslate}
              className={`glow-btn relative filter drop-shadow font-heading text-lg tracking-wider italic font-semibold uppercase px-8 py-3 rounded-xl transition-all flex items-center justify-center gap-2.5 ${isLoading || !inputText.trim() ? "bg-slate-850 border border-slate-800 text-slate-500 cursor-not-allowed" : "bg-cyan-600 hover:bg-cyan-500 text-white cursor-pointer"}`}
              title="Translate (Ctrl+Enter)"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Translating...
                </>
              ) : (
                <>
                  <Languages className="h-4 w-4" />
                  Translate
                </>
              )}
            </motion.button>
          </div>



        </motion.div>

        {/* Translation History Section */}
        <div className="w-full mt-10">
          <div className="flex items-center justify-between mb-4 px-2">
            <h3 className={`text-md font-mono tracking-wider font-semibold flex items-center gap-2 ${isLightMode ? "text-slate-600" : "text-slate-400"}`}>
              <History className="h-4 w-4 text-cyan-500" />
              HISTORY FLUX ({history.length})
            </h3>
            {history.length > 0 && (
              <div className="flex items-center gap-4">
                <button
                  onClick={clearHistory}
                  type="button"
                  className="text-xs font-mono text-rose-500 hover:text-rose-400 flex items-center gap-1.5 transition-all cursor-pointer hover:underline"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Clear History
                </button>
              </div>
            )}
          </div>

          {history.length === 0 ? (
            <div className={`p-8 text-center rounded-xl border border-dashed ${isLightMode ? "bg-white/40 border-slate-200 text-slate-400" : "bg-slate-900/10 border-slate-900 text-slate-600"}`}>
              <p className="text-sm font-body">No galactic communication logs saved in active memory.</p>
            </div>
          ) : (
            <motion.div
              variants={historyContainerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.05 }}
              className="grid grid-cols-1 sm:grid-cols-2 gap-4"
            >
              <AnimatePresence>
                {history.map((h) => (
                  <motion.div
                    key={h.id}
                    layoutId={h.id}
                    variants={historyCardVariants}
                    onClick={() => selectHistoryItem(h)}
                    className={`liquid-glass cursor-pointer p-4 rounded-xl text-left transition-all hover:scale-[1.01] hover:bg-white/[0.04] ${isLightMode ? "text-slate-800 hover:text-slate-950" : "text-slate-100 hover:text-white"}`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-[10px] font-mono tracking-widest uppercase bg-cyan-500/10 text-cyan-400 px-2 py-0.5 rounded">
                        {h.sourceLang.toUpperCase()} → {h.targetLang.toUpperCase()}
                      </span>
                      <span className="text-[10px] font-mono text-slate-500">
                        {new Date(h.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-sm font-semibold tracking-tight line-clamp-1 mb-1">{h.originalText}</p>
                    <p className={`text-xs line-clamp-1 italic ${isLightMode ? "text-slate-500" : "text-slate-400"}`}>{h.translatedText}</p>
                  </motion.div>
                ))}
              </AnimatePresence>
            </motion.div>
          )}
        </div>

      </div>
    </div>
  );
}
