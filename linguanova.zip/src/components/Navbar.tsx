import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";

interface NavbarProps {
  currentView: "voyage" | "translator";
  setView: (view: "voyage" | "translator") => void;
  onNavigateSection?: (sectionId: string) => void;
}

export default function Navbar({ currentView, setView, onNavigateSection }: NavbarProps) {
  return (
    <motion.nav
      initial={{ y: -30, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="fixed top-4 left-0 right-0 w-full z-50 px-4 md:px-8 lg:px-16"
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        
        {/* Left Side Logo: 48x48 liquid glass circle with italic serif lowercase "a" */}
        <button
          onClick={() => setView("voyage")}
          className="w-12 h-12 rounded-full cursor-pointer liquid-glass flex items-center justify-center text-white text-3xl font-heading italic leading-none hover:bg-white/5 transition-all outline-none"
          title="Return to Space Experience"
        >
          a
        </button>

        {/* Center Navigation Pill: px-1.5 py-1.5, holding 5 text links (desktop only) */}
        <div className="hidden md:flex items-center gap-1 liquid-glass rounded-full px-1.5 py-1.5">
          <button
            onClick={() => {
              setView("voyage");
              setTimeout(() => onNavigateSection?.("hero"), 50);
            }}
            className={`cursor-pointer px-4 py-2 text-sm font-medium transition-all font-body rounded-full ${currentView === "voyage" ? "text-white bg-white/10" : "text-white/60 hover:text-white"}`}
          >
            Home
          </button>
          
          <button
            onClick={() => {
              setView("voyage");
              setTimeout(() => onNavigateSection?.("capabilities"), 50);
            }}
            className="cursor-pointer px-4 py-2 text-sm font-medium transition-all font-body text-white/60 hover:text-white rounded-full"
          >
            Voyages
          </button>

          <button
            onClick={() => {
              setView("voyage");
              setTimeout(() => onNavigateSection?.("capabilities"), 50);
            }}
            className="cursor-pointer px-4 py-2 text-sm font-medium transition-all font-body text-white/60 hover:text-white rounded-full"
          >
            Worlds
          </button>

          <button
            onClick={() => {
              setView("voyage");
              setTimeout(() => onNavigateSection?.("capabilities"), 50);
            }}
            className="cursor-pointer px-4 py-2 text-sm font-medium transition-all font-body text-white/60 hover:text-white rounded-full"
          >
            Innovation
          </button>

          <button
            onClick={() => setView("translator")}
            className={`cursor-pointer px-4 py-2 text-sm font-medium transition-all font-body rounded-full ${currentView === "translator" ? "text-white bg-white/10" : "text-white/60 hover:text-white"}`}
          >
            Plan Launch
          </button>
        </div>

        {/* Right Action: White Pill Button 'Claim a Spot' + ArrowUpRight icon */}
        <div className="flex items-center gap-2">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setView(currentView === "voyage" ? "translator" : "voyage")}
            className="cursor-pointer bg-white text-black text-sm font-medium px-6 py-2.5 rounded-full flex items-center justify-center gap-1 hover:bg-slate-100 transition-all font-body whitespace-nowrap shadow-lg outline-none"
          >
            {currentView === "voyage" ? "Open Translator" : "Voyage Hub"}
            <ArrowUpRight className="h-4 w-4 stroke-[2.5]" />
          </motion.button>

          {/* Dummy element for symmetry centering if on desktop, invisible 48x48 spacer */}
          <div className="hidden md:block w-12 h-12 opacity-0 pointer-events-none" />
        </div>

      </div>
    </motion.nav>
  );
}
