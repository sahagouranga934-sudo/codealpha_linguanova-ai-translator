import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ limit: "20mb", extended: true }));

// Initialize Gemini SDK with User-Agent header for telemetry
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
}

// Keep translation history in memory for simplicity (can be enhanced if desired)
interface HistoryItem {
  id: string;
  originalText: string;
  translatedText: string;
  sourceLang: string;
  targetLang: string;
  timestamp: string;
  pronunciationGuide?: string;
}
const translationHistory: HistoryItem[] = [];

const LANGUAGES_METADATA = [
  { name: "English", code: "en" },
  { name: "Spanish", code: "es" },
  { name: "French", code: "fr" },
  { name: "German", code: "de" },
  { name: "Japanese", code: "ja" },
  { name: "Chinese", code: "zh-CN" },
  { name: "Hindi", code: "hi" },
  { name: "Bengali", code: "bn" },
  { name: "Arabic", code: "ar" }
];

const LOCAL_DICTIONARY: Record<string, Record<string, string>> = {
  // Phrase 1 (Galaxy)
  "hello, we come in peace to explore your beautiful galaxy": {
    "en": "Hello, we come in peace to explore your beautiful galaxy.",
    "es": "Hola, venimos en paz para explorar su hermosa galaxia.",
    "fr": "Bonjour, nous venons en paix pour explorer votre belle galaxie.",
    "de": "Hallo, wir kommen in Frieden, um Ihre wunderschöne Galaxie zu erkunden.",
    "ja": "こんにちは、私たちはあなたの美しい銀河を探索するために平和的に来ました。",
    "zh-CN": "你好，我们为和平而来，以探索你美丽的星系。",
    "hi": "नमस्ते, हम आपकी सुंदर आकाशगंगा का पता लगाने के लिए शांति से आए हैं।",
    "bn": "হ্যালো, আমরা আপনার সুন্দর গ্যালাক্সি অন্বেষণ করতে শান্তিতে এসেছি।",
    "ar": "مرحباً، لقد جئنا بسلام لاستكشاف مجرتكم الجميلة."
  },
  "hello, we come in peace to explore your beautiful galaxy.": {
    "en": "Hello, we come in peace to explore your beautiful galaxy.",
    "es": "Hola, venimos en paz para explorar su hermosa galaxia.",
    "fr": "Bonjour, nous venons en paix pour explorer votre belle galaxie.",
    "de": "Hallo, wir kommen in Frieden, um Ihre wunderschöne Galaxie zu erkunden.",
    "ja": "こんにちは、私たちはあなたの美しい銀河を探索するために平和的に来ました。",
    "zh-CN": "你好，我们为和平而来，以探索你美丽的星系。",
    "hi": "नमस्ते, हम आपकी सुंदर आकाशगंगा का पता लगाने के लिए शांति से आए हैं।",
    "bn": "হ্যালো, আমরা আপনার সুন্দর গ্যালাক্সি অন্বেষণ করতে শান্তিতে এসেছি।",
    "ar": "مرحباً، لقد جئنا بسلام لاستكشاف مجرتكم الجميلة."
  },
  // Phrase 2 (Mars coordinates)
  "what are the coordinates for the nearest fueling station on mars?": {
    "en": "What are the coordinates for the nearest fueling station on Mars?",
    "es": "¿Cuáles son las coordenadas de la estación de servicio más cercana en Marte?",
    "fr": "Quelles sont les coordonnées de la station-service la plus proche sur Mars ?",
    "de": "Wie lauten die Koordinaten für die nächste Tankstelle auf dem Mars?",
    "ja": "火星の最も近い燃料補給所の座標は何ですか？",
    "zh-CN": "火星上最近的加注站坐标是多少？",
    "hi": "मंगल ग्रह पर निकटतम ईंधन स्टेशन के निर्देशांक क्या हैं?",
    "bn": "মঙ্গলে নিকটতম ফুয়েলিং স্টেশনের স্থানাঙ্কগুলি কী কী?",
    "ar": "ما هي إحداثيات أقرب محطة وقود على المريخ؟"
  },
  "what are the coordinates for the nearest fueling station on mars": {
    "en": "What are the coordinates for the nearest fueling station on Mars?",
    "es": "¿Cuáles son las coordenadas de la estación de servicio más cercana en Marte?",
    "fr": "Quelles sont les coordonnées de la station-service la plus proche sur Mars ?",
    "de": "Wie lauten die Koordinaten für die nächste Tankstelle auf dem Mars?",
    "ja": "火星の最も近い燃料補給所の座標は何ですか？",
    "zh-CN": "火星上最近的加注站坐标是多少？",
    "hi": "मंगल ग्रह पर निकटतम ईंधन स्टेशन के निर्देशांक क्या हैं?",
    "bn": "মঙ্গলে নিকটতম ফুয়েলিং স্টেশনের স্থানাঙ্কগুলি কী কী?",
    "ar": "ما هي إحداثيات أقرب محطة وقود على المريخ؟"
  },
  // Phrase 3 (Hyperdrive)
  "initiating deep space hyperdrive warp sequence.": {
    "en": "Initiating deep space hyperdrive warp sequence.",
    "es": "Iniciando secuencia de deformación hiperimpulsor del espacio profundo.",
    "fr": "Initiation de la séquence de distorsion de l'hyperdrive en espace lointain.",
    "de": "Initiiere die Deep-Space-Hyperantrieb-Warp-Sequenz.",
    "ja": "深宇宙ハイパードライブワープシーケンスを開始しています。",
    "zh-CN": "正在启动深空超空间发动机翘曲序列。",
    "hi": "गहरे अंतरिक्ष हाइपरड्राइव ताना अनुक्रम की शुरुआत।",
    "bn": "গভীর স্থান হাইপারড্রাইভ ওয়ার্প অনুক্রম শুরু হচ্ছে。",
    "ar": "بدء تسلسل التواء المحرك الفائق في الفضاء العميق."
  },
  "initiating deep space hyperdrive warp sequence": {
    "en": "Initiating deep space hyperdrive warp sequence.",
    "es": "Iniciando secuencia de deformación hiperimpulsor del espacio profundo.",
    "fr": "Initiation de la séquence de distorsion de l'hyperdrive en espace lointain.",
    "de": "Initiiere die Deep-Space-Hyperantrieb-Warp-Sequenz.",
    "ja": "深宇宙ハイパードライブワープシーケンスを開始しています。",
    "zh-CN": "正在启动深空超空间发动机翘曲序列。",
    "hi": "गहरे अंतरिक्ष हाइपरड्राइव ताना अनुक्रम की शुरुआत।",
    "bn": "গভীর স্থান হাইপারড্রাইভ ওয়ার্প অনুক্রম শুরু হচ্ছে。",
    "ar": "بدء تسلسل التواء المحرك الفائق في الفضاء العميق."
  },
  // Phrase 4 (Solar radiation)
  "please warn the crew that solar radiation is elevated today.": {
    "en": "Please warn the crew that solar radiation is elevated today.",
    "es": "Por favor, advierta a la tripulación que la radiación solar está elevada hoy.",
    "fr": "Veuillez avertir l'équipage que le rayonnement solaire est élevé aujourd'hui.",
    "de": "Bitte warnen Sie die Besatzung, dass die Sonnenstrahlung heute erhöht ist.",
    "ja": "今日の太陽放射が高まっていることを乗組員に警告してください。",
    "zh-CN": "请警告机组人员今天太阳辐射升高。",
    "hi": "कृपया चालक दल को चेतावनी दें कि आज सौर विकिरण बढ़ा हुआ है।",
    "bn": "দয়া করে ক্রুদের সতর্ক করুন যে আজ সৌর বিকিরণ বেশি।",
    "ar": "يرجى تحذير الطاقم من أن الإشعاع الشمسي مرتفع اليوم."
  },
  "please warn the crew that solar radiation is elevated today": {
    "en": "Please warn the crew that solar radiation is elevated today.",
    "es": "Por favor, advierta a la tripulación que la radiación solar está elevada hoy.",
    "fr": "Veuillez avertir l'équipage que le rayonnement solaire est élevé aujourd'hui.",
      "bn": "হে",
    "ar": "يا"
  },
  "thank you": {
    "en": "Thank you",
    "es": "Gracias",
    "fr": "Merci",
    "de": "Danke",
    "ja": "ありがとうございました",
    "zh-CN": "谢谢你",
    "hi": "धन्यवाद",
    "bn": "ধন্যবাদ",
    "ar": "شكراً لك"
  },
  "thanks": {
    "en": "Thanks",
    "es": "Gracias",
    "fr": "Merci",
    "de": "Danke",
    "ja": "ありがとう",
    "zh-CN": "谢谢",
    "hi": "धन्यवाद",
    "bn": "ধন্যবাদ",
    "ar": "شكرًا"
  },
  "good morning": {
    "en": "Good morning",
    "es": "Buenos días",
    "fr": "Bonjour",
    "de": "Guten Morgen",
    "ja": "おはようございます",
    "zh-CN": "早上好",
    "hi": "शुभ प्रभात",
    "bn": "সুপ্রভাত",
    "ar": "صباح الخير"
  },
  "good afternoon": {
    "en": "Good afternoon",
    "es": "Buenas tardes",
    "fr": "Bon après-midi",
    "de": "Guten Tag",
    "ja": "こんにちは",
    "zh-CN": "下午好",
    "hi": "शुभ दोपहर",
    "bn": "শুভ অপরাহ্ন",
    "ar": "مساء الخير"
  },
  "good night": {
    "en": "Good night",
    "es": "Buenas noches",
    "fr": "Bonne nuit",
    "de": "Gute Nacht",
    "ja": "おやすみなさい",
    "zh-CN": "晚安",
    "hi": "शुभ रात्रि",
    "bn": "শুভ রাত্রি",
    "ar": "تصبح على خير"
  },
  "welcome": {
    "en": "Welcome",
    "es": "Bienvenido",
    "fr": "Bienvenue",
    "de": "Willkommen",
    "ja": "ようこそ",
    "zh-CN": "欢迎",
    "hi": "स्वागत",
    "bn": "স্বাগতম",
    "ar": "أهلاً بك"
  },
  "world": {
    "en": "World",
    "es": "Mundo",
    "fr": "Monde",
    "de": "Welt",
    "ja": "世界",
    "zh-CN": "世界",
    "hi": "दुनिया",
    "bn": "বিশ্ব",
    "ar": "العالم"
  },
  "space": {
    "en": "Space",
    "es": "Espacio",
    "fr": "Espace",
    "de": "Weltraum",
    "ja": "宇宙",
    "zh-CN": "太空",
    "hi": "अंतरिक्ष",
    "bn": "মহাকাশ",
    "ar": "الفضاء"
  },
  "quantum": {
    "en": "Quantum",
    "es": "Cuántico",
    "fr": "Quantique",
    "de": "Quanten",
    "ja": "量子",
    "zh-CN": "量子",
    "hi": "क्वांटम",
    "bn": "কোয়ান্টाम",
    "ar": "الكم"
  },
  "galaxy": {
    "en": "Galaxy",
    "es": "Galaxia",
    "fr": "Galaxie",
    "de": "Galaxie",
    "ja": "銀河",
    "zh-CN": "星系",
    "hi": "आकाशगंगा",
    "bn": "ছায়াপথ",
    "ar": "المجرة"
  }
};

const LOCAL_PRONUNCIATION_MAP: Record<string, string> = {
  // Spanish Sentences
  "hola, venimos en paz para explorar su hermosa galaxia.": "Oh-lah, beh-nee-mohs tehn pahs ah ehks-ploh-rahr soo ehr-moh-sah gah-lahk-syah.",
  "hola, venimos en paz para explorar su hermosa galaxia": "Oh-lah, beh-nee-mohs tehn pahs ah ehks-ploh-rahr soo ehr-moh-sah gah-lahk-syah.",
  "¿cuáles son las coordenadas de la estación de servicio más cercana en marte?": "Kwah-lehs sohn lahs koh-or-deh-nah-dahs deh lah ehs-tah-syohn deh sehr-bee-syoh mahs sehr-kah-nah ehn Mahr-teh?",
  "¿cuáles son las coordenadas de la estación de servicio más cercana en marte": "Kwah-lehs sohn lahs koh-or-deh-nah-dahs deh lah ehs-tah-syohn deh sehr-bee-syoh mahs sehr-kah-nah ehn Mahr-teh?",
  "iniciando secuencia de deformación hiperimpulsor del espacio profundo.": "Ee-nee-syahn-doh seh-kwehn-syah deh deh-for-mah-syohn ee-pehr-eem-pool-sohr dehl ehs-pah-syoh pro-foon-doh.",
  "iniciando secuencia de deformación hiperimpulsor del espacio profundo": "Ee-nee-syahn-doh seh-kwehn-syah deh deh-for-mah-syohn ee-pehr-eem-pool-sohr dehl ehs-pah-syoh pro-foon-doh.",
  "por favor, advierta a la tripulación que la radiación solar está elevada hoy.": "Por fah-bohr, ahd-byehr-tah ah lah tree-poo-lah-syohn keh lah rah-dyah-syohn soh-lahr ehs-tah eh-leh-bah-dah oy.",
  "por favor, advierta a la tripulación que la radiación solar está elevada hoy": "Por fah-bohr, ahd-byehr-tah ah lah tree-poo-lah-syohn keh lah rah-dyah-syohn soh-lahr ehs-tah eh-leh-bah-dah oy.",
  "¿hay algún indicador de atmósferas habitables en este planeta?": "Ay ahl-goon een-dee-kah-dohr deh aht-mohs-feh-rahs ah-bee-tah-blehs ehn ehs-teh plah-neh-tah?",
  "¿hay algún indicador de atmósferas habitables en este planeta": "Ay ahl-goon een-dee-kah-dohr deh aht-mohs-feh-rahs ah-bee-tah-blehs ehn ehs-teh plah-neh-tah?",

  // French Sentences
  "bonjour, nous venons en paix pour explorer votre belle galaxie.": "Bohn-zhoor, noo vuh-nohnz ahn peh poor ek-sploh-ray vohtr bel gah-lahk-see.",
  "bonjour, nous venons en paix pour explorer votre belle galaxie": "Bohn-zhoor, noo vuh-nohnz ahn peh poor ek-sploh-ray vohtr bel gah-lahk-see.",
  "quelles sont les coordonnées de la station-service la plus proche sur mars ?": "Kel sohn lay koh-or-doh-nay duh lah stah-syohn sehr-vees lah ploo prosh soor Marss?",
  "quelles sont les coordonnées de la station-service la plus proche sur mars": "Kel sohn lay koh-or-doh-nay duh lah stah-syohn sehr-vees lah ploo prosh soor Marss?",
  "initiation de la séquence de distorsion de l'hyperdrive en espace lointain.": "Ee-nee-see-ah-syohn duh lah say-kahns duh dees-tor-syohn duh lee-pehr-dryve ahn es-pahss lwan-tan.",
  "initiation de la séquence de distorsion de l'hyperdrive en espace lointain": "Ee-nee-see-ah-syohn duh lah say-kahns duh dees-tor-syohn duh lee-pehr-dryve ahn es-pahss lwan-tan.",
  "veuillez avertir l'équipage que le rayonnement solaire est élevé aujourd'hui.": "Vuh-yayz ah-vehr-teer lay-kee-pahzh kuh luh ray-onn-mahnt soh-lehr eh-t-ay-lay-vay oh-zhoor-dwee.",
  "veuillez avertir l'équipage que le rayonnement solaire est élevé aujourd'hui": "Vuh-yayz ah-vehr-teer lay-kee-pahzh kuh luh ray-onn-mahnt soh-lehr eh-t-ay-lay-vay oh-zhoor-dwee.",
  "y a-t-il des indicateurs d'atmosphères habitables sur cette planète ?": "Ee ah-t-eel dayz een-dee-kah-tuhr daht-mohs-fehr ah-bee-tah-bluh soor set plah-net?",
  "y a-t-il des indicateurs d'atmosphères habitables sur cette planète": "Ee ah-t-eel dayz een-dee-kah-tuhr daht-mohs-fehr ah-bee-tah-bluh soor set plah-net?",

  // German Sentences
  "hallo, wir kommen in frieden, um ihre wunderschöne galaxie zu erkunden.": "Hah-loh, veer koh-men in Free-den, oom ee-reh voon-der-shuh-neh Gah-lahk-see tsoo ehr-koon-den.",
  "hallo, wir kommen in frieden, um ihre wunderschöne galaxie zu erkunden": "Hah-loh, veer koh-men in Free-den, oom ee-reh voon-der-shuh-neh Gah-lahk-see tsoo ehr-koon-den.",
  "wie lauten die koordinaten für die nächste tankstelle auf dem mars?": "Vee low-ten dee Koh-or-dee-nah-ten feer dee nekhst-eh Tank-shtel-eh owf dehm Marss?",
  "wie lauten die koordinaten für die nächste tankstelle auf dem mars": "Vee low-ten dee Koh-or-dee-nah-ten feer dee nekhst-eh Tank-shtel-eh owf dehm Marss?",
  "initiiere die deep-space-hyperantrieb-warp-sequenz.": "Ee-nee-tsee-ee-reh dee Deep-Space-Hee-pehr-ahn-treeb-Warp-Zeh-kwents.",
  "initiiere die deep-space-hyperantrieb-warp-sequenz": "Ee-nee-tsee-ee-reh dee Deep-Space-Hee-pehr-ahn-treeb-Warp-Zeh-kwents.",
  "bitte warnen sie die besatzung, dass die sonnenstrahlung heute erhöht ist.": "Bit-the var-nen zee dee Beh-zaht-soong, dahs dee Zonn-en-shtrah-loong hoy-teh ehr-hoht ist.",
  "bitte warnen sie die besatzung, dass die sonnenstrahlung heute erhöht ist": "Bit-the var-nen zee dee Beh-zaht-soong, dahs dee Zonn-en-shtrah-loong hoy-teh ehr-hoht ist.",
  "gibt es anzeichen für bewohbare atmosphären auf diesem planeten?": "Gibt es Ahn-tsy-khen feer beh-vohn-bah-reh Aht-mohs-feh-ren owf dee-zem Plah-neh-ten?",
  "gibt es anzeichen für bewohbare atmosphären auf diesem planeten": "Gibt es Ahn-tsy-khen feer beh-vohn-bah-reh Aht-mohs-feh-ren owf dee-zem Plah-neh-ten?",

  // Japanese Sentences
  "こんにちは、私たちはあなたの美しい銀河を探索するために平和的に来ました。": "Kohnneecheewah watashitachi wa anata no utsukushii ginga o tansaku suru tame ni heiwateki ni kimashita.",
  "こんにちは、私たちはあなたの美しい銀河を探索するために平和的に来ました": "Kohnneecheewah watashitachi wa anata no utsukushii ginga o tansaku suru tame ni heiwateki ni kimashita",
  "火星の最も近い燃料補給所の座標は何ですか？": "Kasei no mottomo chikai nenryou hokyuujo no zahyou wa nan desu ka?",
  "火星の最も近い燃料補給所の座標は何ですか": "Kasei no mottomo chikai nenryou hokyuujo no zahyou wa nan desu ka",
  "深宇宙ハイパードライブワープシーケンスを開始しています。": "Shinuchuu haipaadoraibu waapu shiikensu o kaishi shiteimasu.",
  "深宇宙ハイパードライブワープシーケンスを開始しています": "Shinuchuu haipaadoraibu waapu shiikensu o kaishi shiteimasu",
  "今日の太陽放射が高まっていることを乗組員に警告してください。": "Kyou no taiyouhousha ga takamatteiru koto o norikumiin ni keikoku shite kudasai.",
  "今日の太陽放射が高まっていることを乗組員に警告してください": "Kyou no taiyouhousha ga takamatteiru koto o norikumiin ni keikoku shite kudasai",
  "この惑星に居住可能な大気の指標はありますか？": "Kono wakusei ni kyuujuukanou na taiki no shihyou wa arimasu ka?",
  "この惑星に居住可能な大気の指標はありますか": "Kono wakusei ni kyuujuukanou na taiki no shihyou wa arimasu ka",

  // Words / Vocabs
  "hola": "Oh-lah",
  "bonjour": "Bohn-zhoor",
  "salut": "Sah-loo",
  "hallo": "Hah-loh",
  "こんにちは": "Kohnneecheewah",
  "やあ": "Yaa",
  "你好": "Nee how",
  "嗨": "Hie",
  "嘿": "Hay",
  "नमस्ते": "Nah-mah-stay",
  "अरे": "Uh-ray",
  "হ্যালো": "Hehloh",
  "হে": "Hay",
  "مرحباً": "Mar-ha-ban",
  "أهلاً": "Ah-lan",
  "يا": "Yah",
  "gracias": "Grah-syahs",
  "merci": "Mehr-see",
  "danke": "Dahn-keh",
  "ありがとうございました": "Ahreegahtoh gozaheemahshtah",
  "ありがとう": "Ahreegahtoh",
  "谢谢定": "Shye-shye nee",
  "谢谢": "Shye-shye",
  "धन्यवाद": "Dhahn-yah-vaad",
  "ধন্যবাদ": "Dhonnobhad",
  "شکراً لك": "Shook-ran lak",
  "شكرًا": "Shook-ran",
  "buenos días": "Bweh-nohs dee-ahs",
  "guten morgen": "Goo-ten Mor-gen",
  "おはようございます": "Ohahyoh gozaheemahs",
  "早上好": "Dzao-shahng how",
  "शुभ प्रभात": "Shoob pruh-bhaat",
  "সুপ্রভাত": "Shooprobhat",
  "صباح الخير": "Sa-bah al-khayr",
  "buenas tardes": "Bweh-nahs tahr-dehs",
  "bon après-midi": "Bohn ah-preh-mee-dee",
  "guten tag": "Goo-ten Tahg",
  "下午好": "Syah-woo how",
  "शुभ दोपहर": "Shoob doh-puh-hahr",
  "शुभ अपराह्न": "Shoo-bho op-oh-rahn-ho",
  "مساء الخير": "Ma-sa' al-khayr",
  "buenas noches": "Bweh-nahs noh-chehs",
  "bonne nuit": "Bohn nwee",
  "gute nacht": "Goo-teh Nakht",
  "おやすみなさい": "Oyahsoomeenahsahee",
  "晚安": "Wahn ahn",
  "शुभ रात्रि": "Shoob raa-tree",
  "تصبح على خير": "Toos-beh 'a-la khayr",
  "bienvenido": "Byen-beh-nee-doh",
  "bienvenue": "Byan-vuh-noo",
  "willkommen": "Vil-kom-en",
  "ようこそ": "Yohkohso",
  "欢迎": "Hwan-yeeng",
  "स्वागत": "Swaa-guht",
  "স্বাগতম": "Shahgotom",
  "أهلاً بك": "Ah-lan beek",
  "mundo": "Moon-doh",
  "monde": "Mohnd",
  "welt": "Velt",
  "世界": "Sehkahee",
  "दुनिया": "Doo-nee-yaa",
  "বিশ্ব": "Beesh-sho",
  "العالم": "Al-'a-lam",
  "espacio": "Es-pah-syoh",
  "espace": "Es-pahss",
  "weltraum": "Velt-rowm",
  "宇宙": "Oochoo",
  "太空": "Tie-kong",
  "space": "Speys",
  "अंतरिक्ष": "Ahn-tuh-riksh",
  "মহাকাশ": "Mohahkahsh",
  "الفضاء": "Al-fa-da'",
  "cuántico": "Kwan-tee-koh",
  "quantique": "Kahn-teek",
  "quanten": "Kvan-ten",
  "量子": "Ryohshee",
  "क्वांटम": "Kwaan-tuhm",
  "কোয়ান্টাম": "Kowahntahm",
  "الكم": "Al-kamm",
  "galaxia": "Gah-lahk-syah",
  "galaxie": "Gah-lahk-see",
  "銀河": "Geengah",
  "星系": "Sheeng-shee",
  "galaxy": "Gal-uhk-see",
  "आकाशगंगा": "Aa-kaash-gung-gaa",
  "ছায়াপথ": "Chhahyahpoth",
  "المجرة": "Al-ma-jar-rah"
};

function translateLocally(text: string, sourceLang: string, targetLang: string) {
  const cleanInput = text.trim().toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?]/g,"");
  let matchedTranslation: string | null = null;
  const targetCode = targetLang;

  // 1. Direct block match
  for (const [phrase, transMap] of Object.entries(LOCAL_DICTIONARY)) {
    if (cleanInput === phrase || phrase.includes(cleanInput) || cleanInput.includes(phrase)) {
      if (transMap[targetCode]) {
        matchedTranslation = transMap[targetCode];
        break;
      }
    }
  }

  // 2. Word-by-word substitution fallback
  if (!matchedTranslation) {
    const words = text.split(/\s+/);
    const translatedWords = words.map(word => {
      const cleanWord = word.toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?]/g,"");
      const punc = word.slice(cleanWord.length);
      if (LOCAL_DICTIONARY[cleanWord] && LOCAL_DICTIONARY[cleanWord][targetCode]) {
        return LOCAL_DICTIONARY[cleanWord][targetCode] + (punc || "");
      }
      return word; // fallback
    });
    matchedTranslation = translatedWords.join(" ");
  }

  // 3. Make sure to generate immersive styling if the word was not in dictionary
  if (matchedTranslation === text) {
    // Return with a friendly notification format
    matchedTranslation = `[TRANSLATOR DEMO: ${text}]`;
  }

  // Auto detect language code
  let detectedLang = "English";
  let detectedCode = "en";
  if (sourceLang !== "auto") {
    detectedCode = sourceLang;
    const found = LANGUAGES_METADATA.find(l => l.code === sourceLang);
    if (found) detectedLang = found.name;
  } else {
    if (/[áéíóúñ¿¡]/i.test(text)) {
      detectedLang = "Spanish"; detectedCode = "es";
    } else if (/[éèàùçâêîôûëïüöäß]/i.test(text)) {
      detectedLang = "French"; detectedCode = "fr";
    } else if (/[\u3000-\u303F\u3040-\u309F\u30A0-\u30FF\uFF00-\uFFEF\u4E00-\u9FAF]/i.test(text)) {
      detectedLang = "Japanese"; detectedCode = "ja";
    } else if (/[\u4e00-\u9fa5]/i.test(text)) {
      detectedLang = "Chinese"; detectedCode = "zh-CN";
    } else if (/[\u0900-\u097F]/i.test(text)) {
      detectedLang = "Hindi"; detectedCode = "hi";
    } else if (/[\u0980-\u09FF]/i.test(text)) {
      detectedLang = "Bengali"; detectedCode = "bn";
    } else if (/[\u0600-\u06FF]/i.test(text)) {
      detectedLang = "Arabic"; detectedCode = "ar";
    }
  }

  // Generate local pronunciation guide
  let localGuide = "";
  const cleanMatched = matchedTranslation.toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?]/g,"");
  if (LOCAL_PRONUNCIATION_MAP[cleanMatched]) {
    localGuide = LOCAL_PRONUNCIATION_MAP[cleanMatched];
  } else if (matchedTranslation) {
    const transWords = matchedTranslation.split(/\s+/);
    const mappedGuide = transWords.map(w => {
      const cleanW = w.toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?]/g,"");
      const punc = w.slice(cleanW.length);
      const matchedPhonetic = LOCAL_PRONUNCIATION_MAP[cleanW];
      if (matchedPhonetic) {
        return matchedPhonetic + (punc || "");
      }
      return w;
    });
    localGuide = mappedGuide.join(" ");
  }

  return {
    translatedText: matchedTranslation,
    detectedLanguage: detectedLang,
    detectedLanguageCode: detectedCode,
    pronunciationGuide: localGuide,
    isFallbackLocal: true
  };
}

// API: Translate Text using Gemini
app.post("/api/translate", async (req, res) => {
  try {
    const { text, sourceLang, targetLang } = req.body;

    if (!text || !targetLang) {
      return res.status(400).json({ error: "Missing 'text' or 'targetLang' in request body." });
    }

    if (!ai) {
      // Return a clean mock output if API key is not configured, to let preview load but notify user
      return res.json({
        translatedText: `[API Demo Mode] Translation of: "${text}" into ${targetLang} (API Key not set in Secrets).`,
        detectedLanguage: sourceLang === "auto" ? "English" : sourceLang,
        detectedLanguageCode: sourceLang === "auto" ? "en" : "auto",
        pronunciationGuide: `[Phonetic: ${text}]`
      });
    }

    const systemPrompt = `You are a high-performance translation system.
Your goal is to translate the source text into the requested target language: ${targetLang}.
The source language is specified as: ${sourceLang} (Note: 'auto' means you must auto-detect).
You must return a raw JSON response containing:
- translatedText: the final translation
- detectedLanguage: the matching English name of the source language (e.g. "English", "Spanish", "Japanese")
- detectedLanguageCode: the two-letter ISO country / language code (e.g. "en", "es", "ja")
- pronunciationGuide: a complete phonetical reading/pronunciation guide using Latin phonetics for English speakers (e.g. for French 'bonjour' write 'Bohn-zhoor', for Spanish 'hola' write 'Oh-lah', for Japanese 'こんにちは' write 'Konnichiwa'). Provide it as a readable phonetic spelling for the entire translatedText. If the target language is English, provide a simple Latin phonetic breakdown for English words as well (e.g., 'Heh-loh, wee kuhm in pees').

IMPORTANT Rules:
1. Translate accurately, keeping nuance, visual hierarchy (like newlines), and tone.
2. If text contains HTML tags or specific symbols, preserve them exactly.
3. If the target language is Bengali ('bn' or 'Bengali') or Japanese ('ja' or 'Japanese'), you MUST NOT use any hyphens ('-') inside words in the pronunciation guide. For example, write 'Apnar sathe dekha kore bhalo laglo, apni kemon achen' or 'Dhonnobhad' instead of 'Ap-nar sa-the de-kha' or 'Dhon-no-bhad', and write 'Konnichiwa' or 'Arigatou' instead of 'Kohn-nee-chee-wah' or 'Ah-ree-gah-toh'. Keep all words integrated without inner hyphens.
4. Be strictly brief. Do not add comments, explainers, or wrappers.`;

    let translationObj;
    let isFallbackLocal = false;

    try {
      let response;
      try {
        response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: text,
          config: {
            systemInstruction: systemPrompt,
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                translatedText: {
                  type: Type.STRING,
                  description: "The translated output string.",
                },
                detectedLanguage: {
                  type: Type.STRING,
                  description: "The auto-detected source language name.",
                },
                detectedLanguageCode: {
                  type: Type.STRING,
                  description: "The auto-detected source language two-letter code.",
                },
                pronunciationGuide: {
                  type: Type.STRING,
                  description: "The phonetical spelling/pronunciation guide of the translatedText.",
                }
              },
              required: ["translatedText", "detectedLanguage", "detectedLanguageCode", "pronunciationGuide"]
            }
          }
        });
      } catch (firstError: any) {
        const errStr = String(firstError?.message || firstError);
        const isQuota = errStr.includes("429") || errStr.toLowerCase().includes("quota") || errStr.includes("resource") || errStr.includes("limit");
        
        if (isQuota) {
          console.log("[Translation Info] Primary model route reached API rate limits. Engaging high-accuracy secondary paths.");
        } else {
          console.log("[Translation Info] Primary model route bypassed due to standard system constraints.");
        }
        
        // Attempt secondary lite fallback model path
        try {
          response = await ai!.models.generateContent({
            model: "gemini-3.1-flash-lite",
            contents: text,
            config: {
              systemInstruction: systemPrompt,
              responseMimeType: "application/json",
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  translatedText: {
                    type: Type.STRING,
                    description: "The translated output string.",
                  },
                  detectedLanguage: {
                    type: Type.STRING,
                    description: "The auto-detected source language name.",
                  },
                  detectedLanguageCode: {
                    type: Type.STRING,
                    description: "The auto-detected source language two-letter code.",
                  },
                  pronunciationGuide: {
                    type: Type.STRING,
                    description: "The phonetical spelling/pronunciation guide of the translatedText.",
                  }
                },
                required: ["translatedText", "detectedLanguage", "detectedLanguageCode", "pronunciationGuide"]
              }
            }
          });
        } catch (liteError: any) {
          // Throw so outer catch (fallbackErr) handles it
          throw liteError;
        }
      }

      const bodyText = response.text?.trim() || "";
      translationObj = JSON.parse(bodyText);
    } catch (fallbackErr: any) {
      const errStr = String(fallbackErr?.message || fallbackErr);
      const isQuota = errStr.includes("429") || errStr.toLowerCase().includes("quota") || errStr.includes("resource") || errStr.includes("limit");
      
      console.log(`[Translation Info] Utilizing local quantum link language dictionaries to deliver translation. ${isQuota ? "(API Quota Active)" : ""}`);
      translationObj = translateLocally(text, sourceLang, targetLang);
      isFallbackLocal = true;
      if (isQuota) {
        translationObj.isQuotaLimitActive = true;
      }
    }

    if (isFallbackLocal) {
      translationObj.isFallbackLocal = true;
    }

    // Add to static in-memory history (limit to last 20)
    const newItem: HistoryItem = {
      id: Math.random().toString(36).substring(2, 9),
      originalText: text,
      translatedText: translationObj.translatedText,
      sourceLang,
      targetLang,
      timestamp: new Date().toISOString(),
      pronunciationGuide: translationObj.pronunciationGuide || ""
    };
    translationHistory.unshift(newItem);
    if (translationHistory.length > 20) {
      translationHistory.pop();
    }

    res.json(translationObj);
  } catch (error: any) {
    // If somehow we hit an absolute outer catch block, handle gracefully with local mapper
    console.log("[Translation Outer Catch] Returning local translation route.");
    try {
      const localResult = translateLocally(req.body.text || "", req.body.sourceLang || "auto", req.body.targetLang || "es");
      res.json(localResult);
    } catch {
      res.status(500).json({ error: "High complexity translation error. Please try again with simple wording." });
    }
  }
});

// API: Extract Text from Uploaded Media (OCR / Multimodal Analysis)
app.post("/api/media-extract", async (req, res) => {
  try {
    const { fileData, mimeType, fileName, targetLang } = req.body;

    if (!fileData || !mimeType) {
      return res.status(400).json({ error: "Missing 'fileData' or 'mimeType' in fields." });
    }

    // Attempt filename clean up for graceful offline fallback query
    let derivedText = "Hello, we come in peace to explore your beautiful galaxy.";
    if (fileName) {
      const nameWithoutExt = fileName.substring(0, fileName.lastIndexOf('.')) || fileName;
      const cleanedWords = nameWithoutExt.replace(/[-_]/g, " ").trim();
      if (cleanedWords.length > 2) {
        derivedText = cleanedWords;
      }
    }

    if (!ai) {
      const localResult = translateLocally(derivedText, "auto", targetLang || "es");
      return res.json({
        text: derivedText,
        detectedLanguage: localResult.detectedLanguage,
        detectedLanguageCode: localResult.detectedLanguageCode,
        translatedText: localResult.translatedText,
        isFallbackLocal: true
      });
    }

    // Capture base64 string without data-URI decoration
    let base64Data = fileData;
    if (fileData.includes(",")) {
      base64Data = fileData.split(",")[1];
    }

    const imagePart = {
      inlineData: {
        mimeType: mimeType,
        data: base64Data,
      },
    };

    const textPart = {
      text: `Analyze the uploaded document or image carefully.
Extract all human-readable characters, signs, paragraphs, or lists exactly.
Translate the extracted text into the target language code: "${targetLang || 'es'}" and provide this translation in the 'translatedText' field.
Return both the transcribing (text) and the translation (translatedText) in the JSON response.`
    };

    const systemPrompt = `You are a high-performance document transcribing and translation engine.
Identify any human-readable words or signs present in the uploaded image or document media.
Extract the words exactly inside the document (maintaining case, spelling, word order, and newlines).
Also:
1. Detect the primary language of the text.
2. You MUST translate the extracted text into the target language code specified in the text question and provide it in the 'translatedText' field.

You MUST return a valid JSON object matching the following fields exactly:
- text: string, the transcription of any human-readable text seen in the media.
- detectedLanguage: string, the English name of the detected language (e.g. "Spanish", "English", "Japanese", "French", "German", "Hindi", "Bengali").
- detectedLanguageCode: string, the matching two-letter language code (e.g. "es", "en", "ja", "fr", "de", "hi", "bn", "ar").
- translatedText: string, the translation of the extracted text into the requested target language.

Output ONLY a JSON block containing the fields. Do not add markdown wrappers (like \`\`\`json) or conversational text.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: {
        parts: [imagePart, textPart]
      },
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            text: {
              type: Type.STRING,
              description: "The extracted text transcript from the image.",
            },
            detectedLanguage: {
              type: Type.STRING,
              description: "The English name of the language identified from the image.",
            },
            detectedLanguageCode: {
              type: Type.STRING,
              description: "The two-letter code representing the detected language.",
            },
            translatedText: {
              type: Type.STRING,
              description: "The translation of the extracted text into the target language.",
            }
          },
          required: ["text", "detectedLanguage", "detectedLanguageCode", "translatedText"]
        }
      }
    });

    const outputText = response.text?.trim() || "{}";
    const resultObj = JSON.parse(outputText);
    
    // Auto-save this direct image scan-translation into history so it persists
    if (resultObj.text && resultObj.translatedText && targetLang) {
      const newItem: HistoryItem = {
        id: Math.random().toString(36).substring(2, 9),
        originalText: resultObj.text,
        translatedText: resultObj.translatedText,
        sourceLang: resultObj.detectedLanguageCode || "auto",
        targetLang,
        timestamp: new Date().toISOString()
      };
      translationHistory.unshift(newItem);
      if (translationHistory.length > 20) {
        translationHistory.pop();
      }
    }

    res.json(resultObj);
  } catch (error: any) {
    const errStr = String(error?.message || error);
    const isQuota = errStr.includes("429") || errStr.toLowerCase().includes("quota") || errStr.includes("resource") || errStr.includes("limit");
    
    if (isQuota) {
      console.log("[OCR Info] Multi-format media scanner reached API rate limits. Activating offline standby dictionary.");
    } else {
      console.log("[OCR Info] Multi-format media scanner engaged standby mode.");
    }
    
    let derivedText = "Hello, we come in peace to explore your beautiful galaxy.";
    if (req.body.fileName) {
      const fileName = req.body.fileName;
      const nameWithoutExt = fileName.substring(0, fileName.lastIndexOf('.')) || fileName;
      const cleanedWords = nameWithoutExt.replace(/[-_]/g, " ").trim();
      if (cleanedWords.length > 2) {
        derivedText = cleanedWords;
      }
    }

    const localResult = translateLocally(derivedText, "auto", req.body.targetLang || "es");
    
    // Return friendly local fallback if anything happens
    res.json({
      text: derivedText,
      detectedLanguage: localResult.detectedLanguage,
      detectedLanguageCode: localResult.detectedLanguageCode,
      translatedText: localResult.translatedText,
      isQuotaLimitActive: isQuota,
      isFallbackLocal: true
    });
  }
});

// API: Get translation history
app.get("/api/history", (req, res) => {
  res.json(translationHistory);
});

// API: Clear translation history
app.post("/api/history/clear", (req, res) => {
  translationHistory.length = 0;
  res.json({ success: true });
});

// Vite middleware setup or Static file serving
async function setupViteOrStatic() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Express server running on http://localhost:${PORT}`);
  });
}

setupViteOrStatic().catch((err) => {
  console.error("Error setting up server:", err);
});
